package umClient;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.xml.Document;
import java.util.ArrayList;
import java.util.List;
import com.pcbsys.nirvana.client.nChannel;
import com.pcbsys.nirvana.client.nAbstractChannel;
import com.pcbsys.nirvana.client.nChannelAttributes;
import com.pcbsys.nirvana.client.nConsumeEvent;
import com.pcbsys.nirvana.client.nConsumeEventFragmentWriter;
import com.pcbsys.nirvana.client.nEventAttributes;
import com.pcbsys.nirvana.client.nEventProperties;
import com.pcbsys.nirvana.client.nQueue;
import com.pcbsys.nirvana.client.nQueueReaderContext;
import com.pcbsys.nirvana.client.nQueueSyncReader;
import com.pcbsys.nirvana.client.nQueueSyncTransactionReader;
import com.pcbsys.nirvana.client.nSession;
import com.pcbsys.nirvana.client.nSessionAttributes;
import com.pcbsys.nirvana.client.nSessionFactory;
import com.pcbsys.nirvana.client.nTransaction;
import com.pcbsys.nirvana.client.nTransactionAttributes;
import com.pcbsys.nirvana.client.nTransactionFactory;
// --- <<IS-END-IMPORTS>> ---

public final class java

{
	// ---( internal utility methods )---

	final static java _instance = new java();

	static java _newInstance() { return new java(); }

	static java _cast(Object o) { return (java)o; }

	// ---( server methods )---




	public static final void publishTopic (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(publishTopic)>> ---
		// @sigtype java 3.5
		// [i] field:0:required connectionAliasName
		// [i] field:0:required destinationName
		// [i] field:0:optional destinationType {"QUEUE","TOPIC"}
		// [i] record:0:required JMSMessage
		// [i] - record:0:optional header
		// [i] -- field:0:optional deliveryMode {"PERSISTENT","NON_PERSISTENT"}
		// [i] -- object:0:optional priority
		// [i] -- field:0:required replyTo
		// [i] -- object:0:optional timeToLive
		// [i] -- field:0:optional JMSType
		// [i] - record:0:optional properties
		// [i] -- field:0:optional JMS_WMClusterNodes
		// [i] -- field:0:optional activation
		// [i] -- field:0:optional uuid
		// [i] - record:0:optional body
		// [i] -- field:0:optional string
		// [i] -- object:0:optional bytes
		// [i] -- object:0:optional object
		// [i] -- record:0:optional data
		// [i] -- object:0:optional message
		// [i] object:0:optional useCSQ
		// [i] object:0:required Untitled
		// [o] record:0:required JMSMessage
		// [o] - record:0:required header
		// [o] -- field:0:optional JMSCorrelationID
		// [o] -- object:0:required JMSDeliveryMode
		// [o] -- object:0:required JMSDestination
		// [o] -- object:0:required JMSExpiration
		// [o] -- field:0:required JMSMessageID
		// [o] -- object:0:required JMSPriority
		// [o] -- object:0:optional JMSReplyTo
		// [o] -- object:0:required JMSTimestamp
		// [o] -- field:0:optional JMSType
		// [o] - record:0:optional properties
		// [o] -- field:0:optional JMS_WMClusterNodes
		// [o] -- field:0:optional activation
		// [o] -- field:0:optional uuid
		// [o] - record:0:optional body
		// [o] -- field:0:optional string
		// [o] -- object:0:optional bytes
		// [o] -- object:0:optional object
		// [o] -- record:0:optional data
		// [o] -- object:0:optional message
		// 6pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	connectionAliasName = IDataUtil.getString( pipelineCursor, "connectionAliasName" );
			String	destinationName = IDataUtil.getString( pipelineCursor, "destinationName" );
			String	destinationType = IDataUtil.getString( pipelineCursor, "destinationType" );
		    
		    String	deliveryMode=" ";
		    String	rt=" ";
		    String	pr=" ";
		    String	ttl=" ";
		    String	jt=" ";
		    String	jw=" ";
		    String	ac=" ";
		    String	uu=" ";
		    String st=" ";
		    String bytes=" ";
		    String dt="";
		    String msg="";
		    String ob=" ";
			// JMSMessage
			IData	JMSMessage = IDataUtil.getIData( pipelineCursor, "JMSMessage" );
			if ( JMSMessage != null)
			{
				IDataCursor JMSMessageCursor = JMSMessage.getCursor();
		
					// i.header
					IData	header = IDataUtil.getIData( JMSMessageCursor, "header" );
					if ( header != null)
					{
						IDataCursor headerCursor = header.getCursor();
							deliveryMode = IDataUtil.getString( headerCursor, "deliveryMode" );
							
							Object	priority = IDataUtil.get( headerCursor, "priority" );
							if(priority!=null)
							 pr=priority.toString();
							rt = IDataUtil.getString( headerCursor, "replyTo" );
							
							Object	timeToLive = IDataUtil.get( headerCursor, "timeToLive" );
							if(timeToLive!=null)
							ttl=timeToLive.toString();
							  jt = IDataUtil.getString( headerCursor, "JMSType" );
						//headerCursor.destroy();
					}
		
					// i.properties
					IData	properties = IDataUtil.getIData( JMSMessageCursor, "properties" );
					if ( properties != null)
					{
						IDataCursor propertiesCursor = properties.getCursor();
							jw = IDataUtil.getString( propertiesCursor, "JMS_WMClusterNodes" );
						ac = IDataUtil.getString( propertiesCursor, "activation" );
							uu = IDataUtil.getString( propertiesCursor, "uuid" );
						propertiesCursor.destroy();
					}
		
					// i.body
					IData	body = IDataUtil.getIData( JMSMessageCursor, "body" );
					if ( body != null)
					{
						IDataCursor bodyCursor = body.getCursor();
							st = (IDataUtil.getString( bodyCursor, "string" ));
							
							Object	byt = (IDataUtil.get( bodyCursor, "bytes" ));
							if(byt!=null)
								bytes=byt.toString();
							
							Object obj= (IDataUtil.get( bodyCursor, "object" ));
							if(obj!=null)
								ob=obj.toString();
		
							// i.data
							IData	data = IDataUtil.getIData( bodyCursor, "data" );
							if ( data != null)
							{
								IDataCursor dCursor = data.getCursor();
								dt=data.toString();
								
								String s[][]=IDataUtil.getStringTable(dCursor);
							IDataUtil.put( pipelineCursor, s[0][0], "Status" );
								//Object doc= IDataUtil.get( dCursor, "data" );
								
								//while(on!=null)
								//String s=(doc.getAttributes()).toString();
									
							}
								//dt=doc.toString();
							//}
						//	if(data==null)
						//	dt="null";
						/*	
							Object	message = IDataUtil.get( bodyCursor, "message" );
							 msg=message.toString();*/
					//	bodyCursor.destroy();
					}
				//JMSMessageCursor.destroy();
			}
			Object	useCSQ = IDataUtil.get( pipelineCursor, "useCSQ" );
		
		
		try {
			String RNAME = connectionAliasName;
			nSessionAttributes nsa=new nSessionAttributes(RNAME);
			nsa.setRequestPriorityConnection(false);
			nSession session=nSessionFactory.create(nsa);
			session.init();
			String channelName=destinationName;
			nChannelAttributes cattrib = new nChannelAttributes();
			cattrib.setName(channelName);
		
			nChannel testChannel=session.findChannel(cattrib);
			nConsumeEventFragmentWriter fragmentWriter=new nConsumeEventFragmentWriter(testChannel, 10240000);
		  
			 nEventProperties props = new nEventProperties();
			 nEventProperties props1 = new nEventProperties();
			 nEventProperties props2 = new nEventProperties();
			 nEventProperties props3 = new nEventProperties();
			com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Delivery:"+deliveryMode);
			if(deliveryMode!= null)
				  props1.put("deliveryMode",deliveryMode);
			if(pr!=null)
				  props1.put("priority",pr);
			if(rt!=null)
				  props1.put("replyTo", rt);
			if(ttl!=null)
				  props1.put("timeToLive", ttl);
			if(jt!=null)
				  props1.put("JMSType", jt);
			if(jw!=null)
				  props2.put("JMS_WMClusterNodes", jw);
			if(ac!=null)
				  props2.put("activation",ac);
			if(st!=null)
				  props3.put("string",st);
			if(bytes!=null)
				  props3.put("bytes", bytes);
			if(ob!=null)
				  props3.put("object", ob);
			if(dt!=null)
				  props3.put("data", dt);
			if(msg!=null)
				  props3.put("message", msg);
			
				 //props3.put("data",data);
				//  props3.put("message", message);
			if(props1!=null)
				  props.put("header", props1);
			if(props2!=null)
				  props.put("properties", props2);
			if(props3!=null)
				  props.put("body", props3);
			
			
			 // 
			  String res=props.toString();//remove unwanted substrings if needed
				  nConsumeEvent event = new nConsumeEvent("head".getBytes(),res.getBytes());
		  fragmentWriter.publish(event);
		
		} catch (Exception e) {
			 com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Error"+deliveryMode);
			e.printStackTrace(); 
		}
		
		
		
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static void start(String c,String dn,String dt,String ds) throws Exception{
		
		nSessionAttributes nsa=new nSessionAttributes(c);
		nsa.setRequestPriorityConnection(false);
		nSession session=nSessionFactory.create(nsa);
		session.init(); 
	}
	// --- <<IS-END-SHARED>> ---
}

