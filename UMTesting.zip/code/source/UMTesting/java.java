package UMTesting;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.sql.*;
// --- <<IS-END-IMPORTS>> ---

public final class java

{
	// ---( internal utility methods )---

	final static java _instance = new java();

	static java _newInstance() { return new java(); }

	static java _cast(Object o) { return (java)o; }

	// ---( server methods )---




	public static final void sleepThread (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sleepThread)>> ---
		// @sigtype java 3.5
		// [i] field:0:required milliSeconds
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	milliSeconds = IDataUtil.getString( pipelineCursor, "milliSeconds" );
		long longmilliSecond = Long.parseLong(milliSeconds);
		try {
			Thread.sleep(longmilliSecond);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void testDBConnectivity (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(testDBConnectivity)>> ---
		// @sigtype java 3.5
		// [i] field:0:required ServerName
		// [i] field:0:required Port
		// [i] field:0:required SID
		// [i] field:0:required UserName
		// [i] field:0:required Password
		// [o] field:0:required IsSuccess
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	ServerName = IDataUtil.getString( pipelineCursor, "ServerName" );
			String	Port = IDataUtil.getString( pipelineCursor, "Port" );
			String	SID = IDataUtil.getString( pipelineCursor, "SID" );
			String	UserName = IDataUtil.getString( pipelineCursor, "UserName" );
			String	Password = IDataUtil.getString( pipelineCursor, "Password" );
			Connection conn = null;
		String URL = "jdbc:oracle:thin:@" + ServerName + ":" + Port + ":" + SID;
			
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(URL, UserName, Password);
			if (conn != null) {
				com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]", "Tested Sucessfully and connected to DB" );
		    }
			IDataUtil.put( pipelineCursor, "IsSuccess", "Yes" );
			conn.close();		
			if (conn != null) {
				com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]", "Sucessfully Closed DB Connection" );
		    }
						
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]", "Cannot Connect to DB. Please check error Log for more details." );
			IDataUtil.put( pipelineCursor, "IsSuccess", "No" );
			e.printStackTrace();		
		}
			
		//IDataUtil.put( pipelineCursor, "IsSuccess", "IsSuccess" );
		pipelineCursor.destroy();		
			
		// --- <<IS-END>> ---

                
	}
}

