package UMTesting;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Document;
import com.pcbsys.foundation.utils.xmlHelper;
import com.pcbsys.nirvana.base.nConsumeEvent;
import com.pcbsys.nirvana.client.nChannel;
import com.pcbsys.nirvana.client.nChannelAttributes;
import com.pcbsys.nirvana.client.nEventListener;
import com.pcbsys.nirvana.client.nNamedObject;
import com.pcbsys.nirvana.client.nQueue;
import com.pcbsys.nirvana.client.nQueueReaderContext;
import com.pcbsys.nirvana.client.nQueueSyncReader;
import com.pcbsys.nirvana.client.nQueueSyncTransactionReader;
import com.pcbsys.nirvana.client.nSession;
import com.pcbsys.nirvana.client.nSessionAttributes;
import com.pcbsys.nirvana.client.nSessionFactory;
// --- <<IS-END-IMPORTS>> ---

public final class services

{
	// ---( internal utility methods )---

	final static services _instance = new services();

	static services _newInstance() { return new services(); }

	static services _cast(Object o) { return (services)o; }

	// ---( server methods )---




	public static final void suscrib_javaService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(suscrib_javaService)>> ---
		// @sigtype java 3.5
		// [i] field:0:required destinationName
		// [i] field:0:required counnectionService
			try
		{
		IDataCursor pipelineCursor = pipeline.getCursor();
		com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Invoked********* Service:");
		String	destinationName = IDataUtil.getString( pipelineCursor, "destinationName" );
		String	counnectionService = IDataUtil.getString( pipelineCursor, "counnectionService" );
		//@SuppressWarnings("unused")
		com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Invoked********* Service consuming started:");		
		class subChannel implements nEventListener 
		{
			
			public subChannel()throws Exception
			{
				com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Invoked********* Service:"+destinationName +" "+counnectionService);
				nSession session = this.connect(counnectionService);
				nChannel myChannel = this.getChannel(session, destinationName);
				//nNamedObject nobj = myChannel.createNamedObject("check3", 0, true);   
				myChannel.addSubscriber(this,null,myChannel.getLastEID());
				//myChannel.removeSubscriber(this);
				session.close();
			}
			@Override
			public void go(com.pcbsys.nirvana.client.nConsumeEvent event) {
				System.out.println("Consumed event "+event.getEventID()+"eventdata :"+event.getEventData());
				
				try
				{
					byte[] byteString = event.getEventData();
					String byteStr = new String(byteString);
					com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Delivery:String Message:"+byteStr);
				}catch(Exception e)
				{
					com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Delivery:Byte Parsing Exceptionnnnnnnnnnnnnn:"+e.getMessage());
				}
			}
			
			public nSession connect(String rnames){
				nSession connectionObject = null;
				try
				{
					nSessionAttributes sessionAttributes = new nSessionAttributes(rnames);
					connectionObject = nSessionFactory.create(sessionAttributes);
					// connectionObject.enableThreading(10);
					connectionObject.init();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				return connectionObject;
			}
			
			public nChannel getChannel(nSession session, String channelName){
				nChannel channel = null;
				try
				{
					nChannelAttributes cattrib = new nChannelAttributes();
					cattrib.setName(channelName);
					//cattrib.setType(nChannelAttributes.PERSISTENT_TYPE);
					channel = session.findChannel(cattrib);
					//nChannel channel = session.createChannel(cattrib);
					System.out.println("Queue Retrieved: " + channel.getName());
				}catch(Exception e)
				{
					com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Error Occured in Service:");
					e.printStackTrace();
				}
				
				return channel;
			}
		}
		nEventListener obj = new subChannel();
		com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Invoked********* Service End****:");
		
		pipelineCursor.destroy();
		}catch(Exception e)
		{
			com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Invoked********* Service Final Catch****:"+e.getMessage());
		}
		// --- <<IS-END>> ---

                
	}



	public static final void suscrib_queue (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(suscrib_queue)>> ---
		// @sigtype java 3.5
		// [i] field:0:required destinationName
		// [i] field:0:required counnectionService
		try
		{
		IDataCursor pipelineCursor = pipeline.getCursor();
		com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Invoked********* Service:");
		String	destinationName = IDataUtil.getString( pipelineCursor, "destinationName" );
		String	counnectionService = IDataUtil.getString( pipelineCursor, "counnectionService" );
		
		nSession session = connect(counnectionService);
		
		nQueue myQueue = getQueue(session, destinationName);
		
		subscribeToMessages(session, myQueue, 3);
		
		}catch(Exception e)
		{
			com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Invoked********* Service Final Catch****:"+e.getMessage());
		}
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static nQueue getQueue(nSession session, String queueName) throws Exception {
		nChannelAttributes cattrib = new nChannelAttributes();
		cattrib.setName(queueName);
		nQueue queue = session.findQueue(cattrib);
		System.out.println("Queue Retrieved: " + queue.getName());
		return queue;
	}
	
	public static nSession connect(String rnames) throws Exception {
		nSessionAttributes sessionAttributes = new nSessionAttributes(rnames);
		nSession connectionObject = nSessionFactory.create(sessionAttributes);
		// connectionObject.enableThreading(10);
		connectionObject.init();
		return connectionObject;
	}
	public static void subscribeToMessages(nSession session, nQueue queue, int batch) throws Exception {
		nQueueSyncReader reader = queue.createTransactionalReader(new nQueueReaderContext());
		List<nConsumeEvent> eventArray = new ArrayList<nConsumeEvent>();
	
		int onBatch = 0;
		int popNoMessage = 0;
		while (true) {
			//System.out.println("Hiiiiiiiiiiiiiiiiiiiiii");
			if(queue.size() == 0)
			{
				com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Queueee is empty!!!!!!!");
				break;
			}
			com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Queue count is!!!!!!!"+queue.size());
			
			try {
				// System.out.println("About to Pop a message");
				nConsumeEvent evt = reader.pop(100);
				if (evt != null) {
					popNoMessage = 0;
					eventArray.add(evt);
					String tag = evt.getEventTag();
					System.out.println("Popped: " + tag + " into batch:"+evt.getEventData().toString());
				} else {
					popNoMessage++;
				}
	
				if (eventArray.size() == batch) {
					onBatch++;
					System.out.println("Queue Size before doing anything with the batch:" + queue.size());
	
					System.out.println("Reached the batch size - commiting Events up to last ID: " + evt.getEventID()
							+ " Tag: " + evt.getEventTag());
	
					if (onBatch == 2) {
	
						System.out.println("Rolling back batch 2");
						int pos = eventArray.size() - 1;
						long rollbackEventId = eventArray.get(pos).getEventID();
						String rollbackEventTag = eventArray.get(pos).getEventTag();
						System.out
								.println("Rollback Events up to ID: " + rollbackEventId + " Tag: " + rollbackEventTag);
						((nQueueSyncTransactionReader) reader).rollback(rollbackEventId);
						eventArray.clear();
						Thread.sleep(1000);
						System.out.println("Queue Size After rollback:" + queue.size());
					} else {
						((nQueueSyncTransactionReader) reader).commit(evt.getEventID());
						eventArray.clear();
					}
					System.out.println("Queue Size After Commit:" + queue.size());
				} else {
					if (popNoMessage > 10 && eventArray.size() > 0) {
						popNoMessage = 0;
						System.out.println(
								">> Been arround the no messages loop 10 times, check if there's anything in a batch to commit");
	
						nConsumeEvent lastEvt = eventArray.get(eventArray.size() - 1);
	
						System.out.println("Commiting Events up to ID: " + lastEvt.getEventID() + " Tag: "
								+ lastEvt.getEventTag());
						((nQueueSyncTransactionReader) reader).commit(lastEvt.getEventID());
						eventArray.clear();
						new Thread().sleep(1000);
						System.out.println("Queue Size:" + queue.size());
					}
	
				}
			} catch (Exception e) {
				System.out.println("Exception in pop....exiting!");
				e.printStackTrace();
				break;
			}
		}
	
	}
	
		
	// --- <<IS-END-SHARED>> ---
}

