package UMTesting;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.pcbsys.nirvana.client.nChannel;
import com.pcbsys.nirvana.client.nAbstractChannel;
import com.pcbsys.nirvana.client.nChannelAttributes;
import com.pcbsys.nirvana.client.nConsumeEvent;
import com.pcbsys.nirvana.client.nEventAttributes;
import com.pcbsys.nirvana.client.nNamedObject;
import com.pcbsys.nirvana.client.nQueue;
import com.pcbsys.nirvana.client.nQueueReaderContext;
import com.pcbsys.nirvana.client.nQueueSyncReader;
import com.pcbsys.nirvana.client.nQueueSyncTransactionReader;
import com.pcbsys.nirvana.client.nSession;
import com.pcbsys.nirvana.client.nSessionAttributes;
import com.pcbsys.nirvana.client.nSessionFactory;
import com.pcbsys.nirvana.client.nTransaction;
import com.pcbsys.nirvana.client.nTransactionAttributes;
import com.pcbsys.nirvana.client.nTransactionFactory;
// --- <<IS-END-IMPORTS>> ---

public final class createTriggersUM

{
	// ---( internal utility methods )---

	final static createTriggersUM _instance = new createTriggersUM();

	static createTriggersUM _newInstance() { return new createTriggersUM(); }

	static createTriggersUM _cast(Object o) { return (createTriggersUM)o; }

	// ---( server methods )---




	public static final void createTopic_Queue (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createTopic_Queue)>> ---
		// @sigtype java 3.5
		// [i] field:0:required connectionAliasName
		// [i] field:0:required destinationName
		// [i] field:0:required destinationType {"QUEUE","TOPIC"}
		// [i] object:0:required DurableSuscriber
		// [o] field:0:required Status
		// [o] field:0:required Description
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	connectionAliasName = IDataUtil.getString( pipelineCursor, "connectionAliasName" );
			String	destinationName = IDataUtil.getString( pipelineCursor, "destinationName" );
			String	destinationType = IDataUtil.getString( pipelineCursor, "destinationType" );
			Object	DurableSuscriber = IDataUtil.get( pipelineCursor, "DurableSuscriber" );
			String Durable = DurableSuscriber.toString();
			
			try{
				start(connectionAliasName,destinationName,destinationType,Durable);
				}
				catch(Exception e)
				{
					com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Error Occured while calling Service");
					e.printStackTrace();
				}
			
		
		IDataUtil.put( pipelineCursor, "Status", "Status" );
		IDataUtil.put( pipelineCursor, "Description", "Description" );
		pipelineCursor.destroy();
		
			 
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	public static void start(String c,String dn,String dt,String ds) throws Exception{
		
		nSessionAttributes nsa=new nSessionAttributes(c);
		nsa.setRequestPriorityConnection(false);
		nSession session=nSessionFactory.create(nsa);
		session.init();
		
	if (dt.equalsIgnoreCase("TOPIC"))
	
	{ 
		if (ds.equalsIgnoreCase("true"))
		{
		nChannelAttributes cattrib = new nChannelAttributes();
		cattrib.setName(dn);
		String dsn = dn +"Durable";
		nChannel test=session.createChannel(cattrib);
		test.createSharedNamedObject(dsn, true, false,0);
		com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Topic Created: " + dn +" Durable Subscriber: "+ dsn);
		}
		
		else 
		{ 
			nChannelAttributes cattrib = new nChannelAttributes();
			cattrib.setName(dn);
			session.createChannel(cattrib);
			com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","Topic Created " + dn);			
		}
		}
	
	else
	
	{
		nChannelAttributes cattrib = new nChannelAttributes();
		cattrib.setChannelMode(nChannelAttributes.QUEUE_MODE);
		//cattrib.setMaxEvents(0);
		//cattrib.setTTL(0);
		cattrib.setType(nChannelAttributes.PERSISTENT_TYPE);
		cattrib.setName(dn);
		session.createQueue(cattrib);
		
		com.wm.util.JournalLogger.log(4,90,3,"[MY.JAVAService.LOG]","QUEUE Created " + dn );
	}
	
	
		
	}	
	
	public nSession connect(String rnames) throws Exception {
		nSessionAttributes sessionAttributes = new nSessionAttributes(rnames);
		nSession connectionObject = nSessionFactory.create(sessionAttributes);
		connectionObject.init();
		return connectionObject;
	}
	
		
	// --- <<IS-END-SHARED>> ---
}

